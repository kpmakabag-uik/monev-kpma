import { auth } from "@/auth";
import prisma from "@/lib/prisma";
import { redirect } from "next/navigation";
import Link from "next/link";

interface Faculty {
  id: string;
  name: string;
}

interface Prodi {
  id: string;
  name: string;
  jenjang: string;
  faculty: Faculty;
}

export default async function LaporanMainPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const userRole = session.user.role;
  const userFaculty = session.user.facultyId;
  const userProdi = session.user.prodiId;

  // 1. Fetch accessible Prodis based on role
  let prodis: Prodi[] = [];
  if (userRole === "KPMA" || userRole === "PIMPINAN_UNIVERSITAS") {
    prodis = await prisma.prodi.findMany({ include: { faculty: true } });
  } else if (userRole === "GPM" || userRole === "PIMPINAN_FAKULTAS") {
    prodis = await prisma.prodi.findMany({ 
      where: { facultyId: userFaculty || undefined },
      include: { faculty: true }
    });
  } else if (userRole === "GKM") {
    prodis = await prisma.prodi.findMany({
      where: { id: userProdi || undefined },
      include: { faculty: true }
    });
  }

  // 2. Fetch cycles
  const cycles = await prisma.cycle.findMany({
    orderBy: [
      { tahun_akademik: 'desc' },
      { semester: 'desc' }
    ]
  });

  const activeCycle = cycles.find(c => c.isActive) || cycles[0];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Laporan MONEV</h1>
        <p className="text-gray-500 mt-1">Pilih Program Studi dan Siklus untuk mencetak laporan isian data.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50 text-gray-600 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-6 py-4">Fakultas</th>
                <th className="px-6 py-4">Program Studi</th>
                <th className="px-6 py-4">Siklus Aktif</th>
                <th className="px-6 py-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {prodis.map((prodi) => (
                <tr key={prodi.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900">{prodi.faculty.name}</td>
                  <td className="px-6 py-4 text-gray-600">
                    <span className="font-bold text-institusi mr-2">[{prodi.jenjang}]</span>
                    {prodi.name}
                  </td>
                  <td className="px-6 py-4">
                    {activeCycle ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {activeCycle.tahun_akademik} - {activeCycle.semester}
                      </span>
                    ) : (
                      <span className="text-gray-400">Belum diatur</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Link 
                      href={`/laporan/${prodi.id}?tahun=${activeCycle?.tahun_akademik}&semester=${activeCycle?.semester}`}
                      className="inline-flex items-center gap-2 bg-institusi hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-sm"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                      Buka Laporan
                    </Link>
                  </td>
                </tr>
              ))}
              {prodis.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-gray-500 italic">
                    Tidak ada Program Studi yang tersedia.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
