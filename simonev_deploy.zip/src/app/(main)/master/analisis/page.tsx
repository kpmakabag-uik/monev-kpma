import { auth } from "@/auth";
import { redirect } from "next/navigation";

export default async function AnalisisPage() {
  const session = await auth();
  if (session?.user?.role !== "KPMA") redirect("/dashboard");
  // Basic query just for demo
  // const records = await prisma.monevRecord.findMany({
  //   include: { prodi: true, instrument: true },
  //   where: { 
  //      analisa_kpma: { not: "" },
  //   }
  // });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analisis & Tindak Lanjut (Global)</h1>
          <p className="text-gray-500 mt-1">Rekapitulasi analisis yang pernah diberikan oleh tim KPMA atas form program studi.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 text-center text-gray-500">
         Jika Anda ingin melihat rekapitulasi analisis KPMA berdasarkan Prodi, tabel akan muncul di sini. 
         Saat ini fitur rekap global masih dalam tahap perancangan format.
      </div>
    </div>
  );
}
