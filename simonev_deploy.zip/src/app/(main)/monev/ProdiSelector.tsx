"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";

interface Prodi {
  id: string;
  name: string;
  jenjang: string;
}

export default function ProdiSelector({ 
  prodis, 
  selectedId 
}: { 
  prodis: Prodi[], 
  selectedId: string | null 
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pathname = usePathname();

  const handleSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newProdiId = e.target.value;
    const params = new URLSearchParams(searchParams.toString());
    params.set('prodiId', newProdiId);
    router.push(`${pathname}?${params.toString()}`);
  };

  return (
    <div className="flex flex-col">
      <label htmlFor="prodi" className="text-xs font-semibold text-gray-500 mb-1">
        Fokus Program Studi:
      </label>
      <select
        id="prodi"
        value={selectedId || ""}
        onChange={handleSelect}
        className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-institusi focus:border-institusi block w-full p-2.5 shadow-sm min-w-[250px] transition-colors"
      >
        <option value="" disabled>Pilih Program Studi</option>
        {prodis.map(p => (
          <option key={p.id} value={p.id}>
            {p.name} ({p.jenjang})
          </option>
        ))}
      </select>
    </div>
  );
}
