"use server";

import prisma from "@/lib/prisma";
import { auth } from "@/auth";

interface AnswerItem {
  evaluasiDiri?: string;
  pilihan?: string;
  buktiLinks?: string[];
  catatanAuditor?: string;
  kesesuaianBukti?: string;
}

export async function saveMonevRecord({
  prodiId,
  instrumentId,
  tahunAkademik,
  semester,
  answers,
  analisaKpma,
  tindakLanjutKpma
}: {
  prodiId: string;
  instrumentId: string;
  tahunAkademik: string;
  semester: string;
  answers: Record<string, AnswerItem>;
  analisaKpma: string;
  tindakLanjutKpma: string;
}) {
  try {
    const session = await auth();
    if (!session?.user) return { success: false, error: "Unauthorized" };

    const role = session.user.role;
    
    // In a real app we could rigorously validate if they changed restricted fields, 
    // but the Client Component already disables them.
    // For upsert, we might want to fetch existing first, and ONLY apply modifications on allowed fields
    
    // Simple path: Upsert all fields that are passed from client
    // Note: To be secure, Backend should reconstruct the JSON by only replacing allowed fields.
    
    const existing = await prisma.monevRecord.findUnique({
      where: {
        prodiId_instrumentId_tahun_akademik_semester: {
          prodiId, instrumentId, tahun_akademik: tahunAkademik, semester
        }
      }
    });

    const mergedAnswers: Record<string, AnswerItem> = existing ? JSON.parse(existing.answers as string) : {};
    
    // Merge answers based on role permissions
    Object.keys(answers).forEach(qId => {
      if (!mergedAnswers[qId]) mergedAnswers[qId] = {};
      
      const qAns = answers[qId];
      if (role === "GKM" || role === "KPMA") {
        // GKM & KPMA can fill main answers and upload evidence
        mergedAnswers[qId].evaluasiDiri = qAns.evaluasiDiri;
        mergedAnswers[qId].pilihan = qAns.pilihan;
        if (qAns.buktiLinks) mergedAnswers[qId].buktiLinks = qAns.buktiLinks;
      }
      
      if (role === "GPM" || role === "KPMA") {
        // GPM & KPMA can fill audit notes
        mergedAnswers[qId].catatanAuditor = qAns.catatanAuditor;
        mergedAnswers[qId].kesesuaianBukti = qAns.kesesuaianBukti;
      }
    });

    const finalAnalisa = role === "KPMA" ? analisaKpma : (existing?.analisa_kpma || "");
    const finalTindakLanjut = role === "KPMA" ? tindakLanjutKpma : (existing?.tindak_lanjut_kpma || "");

    await prisma.monevRecord.upsert({
      where: {
        prodiId_instrumentId_tahun_akademik_semester: {
          prodiId, instrumentId, tahun_akademik: tahunAkademik, semester
        }
      },
      update: {
        answers: JSON.stringify(mergedAnswers),
        analisa_kpma: finalAnalisa,
        tindak_lanjut_kpma: finalTindakLanjut,
      },
      create: {
        prodiId,
        instrumentId,
        tahun_akademik: tahunAkademik,
        semester,
        answers: JSON.stringify(mergedAnswers),
        analisa_kpma: finalAnalisa,
        tindak_lanjut_kpma: finalTindakLanjut,
      }
    });

    return { success: true };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan";
    console.error("Save Error:", err);
    return { success: false, error: message };
  }
}

export async function importPreviousCycleData(prodiId: string) {
  try {
    const session = await auth();
    if (!session?.user) return { success: false, error: "Unauthorized" };

    // 1. Get current active cycle
    const currentCycle = await prisma.cycle.findFirst({ where: { isActive: true } });
    if (!currentCycle) return { success: false, error: "Tidak ada siklus aktif ditemukan." };

    // 2. Get previous cycle (latest before current)
    const allCycles = await prisma.cycle.findMany({
      orderBy: [
        { tahun_akademik: 'desc' },
        { semester: 'desc' }
      ]
    });
    
    const currentIndex = allCycles.findIndex(c => c.id === currentCycle.id);
    const prevCycle = allCycles[currentIndex + 1];

    if (!prevCycle) return { success: false, error: "Tidak ada data siklus sebelumnya yang bisa diimpor." };

    // 3. Get all records from previous cycle for this prodi
    const prevRecords = await prisma.monevRecord.findMany({
      where: {
        prodiId,
        tahun_akademik: prevCycle.tahun_akademik,
        semester: prevCycle.semester
      }
    });

    if (prevRecords.length === 0) return { success: false, error: "Tidak ditemukan data pada siklus sebelumnya." };

    // 4. Process each record
    let importedCount = 0;
    for (const oldRec of prevRecords) {
      let oldAnswers: Record<string, AnswerItem> = {};
      try {
        oldAnswers = JSON.parse(oldRec.answers as string);
      } catch { continue; }
      
      // Clean answers: we only want the GKM parts
      const cleanAnswers: Record<string, AnswerItem> = {};
      Object.keys(oldAnswers).forEach(qId => {
        const item = oldAnswers[qId];
        cleanAnswers[qId] = {
          evaluasiDiri: item.evaluasiDiri,
          pilihan: item.pilihan,
          buktiLinks: item.buktiLinks
        };
      });

      // Find current record
      const existing = await prisma.monevRecord.findUnique({
        where: {
          prodiId_instrumentId_tahun_akademik_semester: {
            prodiId, 
            instrumentId: oldRec.instrumentId, 
            tahun_akademik: currentCycle.tahun_akademik, 
            semester: currentCycle.semester
          }
        }
      });

      let finalAnswers = cleanAnswers;
      if (existing) {
        // If current record exists, merge: only fill what is currently empty
        const currentAns: Record<string, AnswerItem> = JSON.parse(existing.answers as string);
        Object.keys(cleanAnswers).forEach(qId => {
           if (!currentAns[qId]) currentAns[qId] = {};
           const cleanItem = cleanAnswers[qId];
           // Only copy if current is empty/null
           if (!currentAns[qId].pilihan) currentAns[qId].pilihan = cleanItem.pilihan;
           if (!currentAns[qId].evaluasiDiri) currentAns[qId].evaluasiDiri = cleanItem.evaluasiDiri;
           if (!currentAns[qId].buktiLinks || currentAns[qId].buktiLinks.length === 0) {
             currentAns[qId].buktiLinks = cleanItem.buktiLinks;
           }
        });
        finalAnswers = currentAns;
      }

      await prisma.monevRecord.upsert({
        where: {
          prodiId_instrumentId_tahun_akademik_semester: {
            prodiId,
            instrumentId: oldRec.instrumentId,
            tahun_akademik: currentCycle.tahun_akademik,
            semester: currentCycle.semester
          }
        },
        update: { answers: JSON.stringify(finalAnswers) },
        create: {
          prodiId,
          instrumentId: oldRec.instrumentId,
          tahun_akademik: currentCycle.tahun_akademik,
          semester: currentCycle.semester,
          answers: JSON.stringify(finalAnswers)
        }
      });
      importedCount++;
    }

    return { success: true, count: importedCount, from: `${prevCycle.tahun_akademik} ${prevCycle.semester}` };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan";
    console.error("Import Error:", err);
    return { success: false, error: message };
  }
}

export async function getProdiMonevReport(prodiId: string, tahunAkademik: string, semester: string) {
  try {
    const session = await auth();
    if (!session?.user) return { success: false, error: "Unauthorized" };

    const records = await prisma.monevRecord.findMany({
      where: {
        prodiId,
        tahun_akademik: tahunAkademik,
        semester
      },
      include: {
        instrument: true
      }
    });

    const prodi = await prisma.prodi.findUnique({
      where: { id: prodiId },
      include: { faculty: true }
    });

    return { 
      success: true, 
      records: records.map(r => ({
        ...r,
        answers: JSON.parse(r.answers as string)
      })),
      prodi
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan";
    console.error("Report Fetch Error:", err);
    return { success: false, error: message };
  }
}
