"use client";

import { useTransition, useState } from "react";
import { loginAction } from "@/app/actions/auth";
import Image from "next/image";

export default function LoginPage() {
  const [error, setError] = useState("");
  const [isPending, startTransition] = useTransition();

  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    const formData = new FormData(e.currentTarget);
    
    startTransition(async () => {
      try {
        const result = await loginAction(formData);
        if (result?.error) {
          setError(result.error);
        }
      } catch {
        // Successful login will redirect and exit the page context
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Image src="/logo-kpma.png" alt="Logo KPMA" width={96} height={96} className="drop-shadow-xl" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900 tracking-tight">
          Login ke SiMONEV
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Monitoring dan Evaluasi Mutu Perguruan Tinggi
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl shadow-gray-200/50 sm:rounded-2xl sm:px-10 border border-gray-100">
          <form className="space-y-6" onSubmit={handleLogin}>
            <div>
              <label
                htmlFor="username"
                className="block text-sm font-medium text-gray-700"
              >
                Username
              </label>
              <div className="mt-1">
                <input
                  id="username"
                  name="username"
                  type="text"
                  required
                  className="appearance-none block w-full px-3 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-institusi focus:border-institusi sm:text-sm transition-colors"
                  placeholder="Masukkan username Anda"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700"
              >
                Password
              </label>
              <div className="mt-1">
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  className="appearance-none block w-full px-3 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-institusi focus:border-institusi sm:text-sm transition-colors"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <div className="rounded-md bg-red-50 p-4 border border-red-200">
                <div className="flex">
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">{error}</h3>
                  </div>
                </div>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={isPending}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-md hover:shadow-lg text-sm font-medium text-white bg-institusi hover:bg-[#153a6b] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-institusi transition-all disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isPending ? "Masuk..." : "Masuk"}
              </button>
            </div>
            
            <div className="mt-6 text-center text-xs text-gray-500 border-t border-gray-100 pt-6">
              © {new Date().getFullYear()} KPMA UIKA Bogor. <br />
              All rights reserved.
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
